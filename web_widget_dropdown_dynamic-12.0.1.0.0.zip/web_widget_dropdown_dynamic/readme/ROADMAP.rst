 * In v13, ``$.when`` is going to become `Promise.resolve`
