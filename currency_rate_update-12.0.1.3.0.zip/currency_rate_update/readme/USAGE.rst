To update historical currency rates:

# Go to *Invoicing > Configuration > Currency Rates Providers*
# Select specific providers
# Launch *Actions > Update Rates Wizard*
# Configure date interval and click *Update*
